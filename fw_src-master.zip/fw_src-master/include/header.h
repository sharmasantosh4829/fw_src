# include <stdio.h>
# include <math.h>
# include "../lib/addSub.c"
# include "../lib/mulDiv.c"

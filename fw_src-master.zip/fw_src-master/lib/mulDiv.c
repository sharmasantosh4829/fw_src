# include <stdio.h>

double mul(double num1, double num2)
{
	return (num1*num2);
}

double div(double num1, double num2)
{
	return (num1/num2);
}
